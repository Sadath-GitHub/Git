package Math.GCD;
/*
standard input/output: 2s/128000 kB

There is a function F defined as,
F(x) = GCD(1, x) + GCD(2, x) +. . + GCD(x, x)
Your task is to find F(x), for the given x.
Input
First line contain integer T denoting number of test cases.
Next t lines contain an integer x.

Constraints
1 <= T <= 20000
1 <= x <= 100000
Output
For each test case print F(n) in separate line
Example
Sample Input
5
1
2
3
4
5
Sample output
1
3
5
8
9
 */
public class SumOfGcd {
    public static  long sumOfGCd(int x)
    {
        return 0;
    }

    public static void main(String[] args) {

    }
}
