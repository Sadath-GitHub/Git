package com.company.Array.DsaArena_1DArrays;

public class SubArraySumZero {
    public static void f1(int[] arr){
        System.out.println(arr.hashCode());
    }

    public static void main(String[] args) {
        int [] arr={10};
        System.out.println(arr.hashCode());
        f1(arr);

    }
}
