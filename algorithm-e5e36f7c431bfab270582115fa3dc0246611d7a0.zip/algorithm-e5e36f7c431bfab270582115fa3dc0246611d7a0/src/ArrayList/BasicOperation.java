package ArrayList;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;

public class BasicOperation {
    public static void main(String[] args) {
        HashSet hs = new HashSet();
        hs.add("AAdarsh");
        // System.out.println(hs.get(0));
    }

}
