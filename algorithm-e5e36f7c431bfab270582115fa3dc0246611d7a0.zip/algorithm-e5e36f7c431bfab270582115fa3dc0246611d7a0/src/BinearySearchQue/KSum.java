package BinearySearchQue;

public class KSum {
}
