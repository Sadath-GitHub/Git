package QueueConcept.GFG;

import java.util.LinkedList;
import java.util.PriorityQueue;
import java.util.Queue;

public class QueueClassInJava {
    public static void main(String[] args) {
        Queue<Integer> queue=new LinkedList<>();

        System.out.println(queue);
       queue.add(10);

    }
}
