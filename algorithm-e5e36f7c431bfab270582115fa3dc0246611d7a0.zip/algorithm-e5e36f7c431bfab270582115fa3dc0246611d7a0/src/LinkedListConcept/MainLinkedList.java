package LinkedListConcept;

public class MainLinkedList {
    public static void main(String[] args) {
        MyLinkedList ll=new MyLinkedList();
        ll.add(22);
        ll.add(56);
        ll.add("A");
        ll.print();
    }
}
